# Código web de Yury Chacón · Rebelde Digital

## Contenido

- `sitio-web/index.html`: estructura y textos de la página.
- `sitio-web/assets/styles.css`: diseño, colores y adaptación a teléfonos.
- `sitio-web/assets/site.js`: menú, formulario, WhatsApp y correo.
- `sitio-web/assets/`: logotipo, fotografías e iconos.

## Opción 1: conservar el alojamiento actual

La página ya está alojada en Sites. Después de comprar `unarebeldedigital.com`, se puede vincular el dominio al sitio existente.

1. Añadir `unarebeldedigital.com` y, si se desea, `www.unarebeldedigital.com` al sitio.
2. Copiar en el panel DNS del proveedor los registros de validación y conexión entregados por Sites.
3. Esperar la validación del dominio y la activación del certificado SSL.
4. Cambiar el acceso del sitio a público cuando esté listo para recibir visitantes.

No hace falta contratar un segundo alojamiento para esta opción.

## Opción 2: publicar en Hostinger u otro hosting

1. Contratar un plan de hosting y vincular el dominio.
2. Abrir el administrador de archivos del hosting.
3. Entrar en la carpeta `public_html`.
4. Subir el contenido de la carpeta `sitio-web`. `index.html` debe quedar directamente dentro de `public_html`.
5. Mantener la carpeta `assets` junto a `index.html`.
6. Activar el certificado SSL y comprobar la página con `https://`.

## Formulario

El botón de WhatsApp abre una conversación con el mensaje preparado. El botón de correo abre la aplicación de correo del visitante. Esta versión no necesita base de datos ni servidor.

## Antes de publicar

- Verificar que el número de WhatsApp siga vigente.
- Comprobar el correo de contacto.
- Revisar precios y métodos de pago.
- Abrir la página desde un teléfono y una computadora.
