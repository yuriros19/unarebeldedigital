const menuButton=document.querySelector('.menu-button');
const menu=document.querySelector('.main-nav');
menuButton.addEventListener('click',()=>{const open=menu.classList.toggle('open');menuButton.setAttribute('aria-expanded',String(open));});
menu.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{menu.classList.remove('open');menuButton.setAttribute('aria-expanded','false');}));

const form=document.querySelector('#contact-form');
const status=document.querySelector('#form-status');
const serviceSelect=document.querySelector('#service');
document.querySelectorAll('.service-link').forEach(link=>link.addEventListener('click',()=>{serviceSelect.value=link.dataset.service||'';}));

function formMessage(){
  const name=document.querySelector('#name').value.trim();
  const business=document.querySelector('#business').value.trim()||'No indicado';
  const service=serviceSelect.value;
  const message=document.querySelector('#message').value.trim();
  return `Hola, Yury. Conocí tus servicios en la página web y quiero información sobre ${service}.\n\nNombre: ${name}\nMarca o negocio: ${business}\n¿Qué quiero mejorar?: ${message}`;
}
function ready(){
  if(!form.reportValidity()){status.textContent='Completa los campos requeridos antes de enviar.';return false;}
  status.textContent='';return true;
}
document.querySelector('#send-whatsapp').addEventListener('click',()=>{if(!ready())return;window.open(`https://wa.me/584247798405?text=${encodeURIComponent(formMessage())}`,'_blank','noopener');status.textContent='Tu mensaje está listo en WhatsApp.';});
document.querySelector('#send-email').addEventListener('click',()=>{if(!ready())return;const subject=`Solicitud web: ${serviceSelect.value}`;window.location.href=`mailto:unarebeldedigital@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(formMessage())}`;status.textContent='Se abrió tu aplicación de correo con el mensaje preparado.';});
document.querySelector('#year').textContent=new Date().getFullYear();
